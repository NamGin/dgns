<?php
require_once __DIR__ . '/vendor/autoload.php'; // thêm dòng này để xuất file excel
require_once 'core/Autoloader.php';
require_once 'config/config.php';
require_once 'core/App.php';
$app = new \Core\App(); 